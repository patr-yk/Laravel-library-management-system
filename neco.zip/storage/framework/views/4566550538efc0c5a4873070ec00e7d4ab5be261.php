<?php $__env->startSection('content'); ?>

    <div id="admin-content">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h2 class="admin-heading">Všechny knihy</h2>
                </div>
                <div class="offset-md-7 col-md-2">
                    <a class="add-new" href="<?php echo e(route('book.create')); ?>">Přidat knihu</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="message"></div>
                    <table class="content-table">
                        <thead>
                            <th>ISBN</th>
                            <th>Název</th>
                            <th>Kategorie</th>
                            <th>Autor</th>
                            <th>Vydavatel</th>
                            <th>Stav</th>
														<th>Náhled</th>
                            <th>Upravit</th>
                            <th>Odstranit</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="id"><?php echo e($book->isbn ?? "---"); ?></td>
                                    <td><?php echo e($book->name ?? "---"); ?></td>
                                    <td><?php echo e($book->category->name ?? "---"); ?></td>
                                    <td><?php echo e($book->auther->name ?? "---"); ?></td>
                                    <td><?php echo e($book->publisher->name ?? "---"); ?></td>
                                    <td>
                                        <?php if($book->status == 'Y'): ?>
                                            <span class='badge badge-success'>Dostupé</span>
                                        <?php else: ?>
                                            <span class='badge badge-danger'>Vypůjčeno</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="edit">
                                        <a href="<?php echo e(route('book.edit', $book)); ?>" class="btn btn-success">Upravit</a>
                                    </td>
																		<td class="view">
																			<a href="<?php echo e(route('book.view', $book)); ?>" class="btn btn-success">Náhled</a>
																		</td>
                                    <td class="delete">
                                        <form action="<?php echo e(route('book.destroy', $book)); ?>" method="post"
                                            class="form-hidden">
                                            <button class="btn btn-danger delete-book">Odstranit</button>
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8">Žádné knihy nebyly nalezeny</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($books->links('vendor/pagination/bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patryk/eclipse-workspace/Laravel-library-management-system/resources/views/book/index.blade.php ENDPATH**/ ?>