<?php $__env->startSection('content'); ?>
	<div id="admin-content">
			<div class="container">
					<div class="row">
							<div class="col-md-3">
									<h2 class="admin-heading">Náhled knihy</h2>
							</div>
							<div class="offset-md-7 col-md-2">
									<a class="add-new" href="<?php echo e(route('books')); ?>">Zpět</a>
							</div>
					</div>
					<div class="row">
							<div class="offset-md-3 col-md-6">
									<div class="yourform container">
										<div class="row mb-5">
											<div class="col-6"><h4><b><?php echo e($book->name); ?></b></h4></div>
											<div class="col-6"><a class="add-new align-right" href="<?php echo e(route('book.edit', $book->id)); ?>">Upravit</a></div>
										</div>



										<div class="row">
											<div class="col-6">

											<p class="box">
												<b>ISBN</b><br/>
												<?php echo e($book->isbn ?? "---"); ?>

											</p>

											<p class="box">
												<b>Formát</b><br/>
												<?php echo e($book->format ?? "---"); ?>

											</p>

											<p class="box">
												<b>Počet stran</b><br/>
												<?php echo e($book->pageNumber ?? "---"); ?>

											</p>

											<p class="box">
												<b>Umístšní</b><br/>
												<?php echo e($book->place ?? "---"); ?>

											</p>

											<p class="box">
												<b>Vlastník</b><br/>
												<?php echo e($book->owner->name ?? "---"); ?>

											</p>

											<p class="box">
												<b>Komentář</b><br/>
												<?php echo e($book->comment ?? "---"); ?>

											</p>

										</div>


										<div class="col-6">
										<p class="box">
											<b>Autor</b><br/>
											<?php echo e($book->auther->name ?? "---"); ?>

										</p>

										<p class="box">
											<b>Kategorie</b><br/>
											<?php echo e($book->category->name ?? "---"); ?>

										</p>

										<p class="box">
											<b>Vydavatel</b><br/>
											<?php echo e($book->publisher->name ?? "---"); ?>

										</p>

										<p class="box">
											<b>Rok vydání</b><br/>
											<?php echo e($book->releaseDate ?? "---"); ?>

										</p>

										<p class="box">
											<b>Jazyk</b><br/>
											<?php echo e($book->language ?? "---"); ?>

										</p>

									</div>
									<p class="box">
										<b>Shrnutí</b><br/>
										<?php echo $book->resume ?? "---"; ?>

									</p>
										</div>

									</div>
									</div>
							</div>
					</div>
			</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patryk/eclipse-workspace/Laravel-library-management-system/resources/views/book/view.blade.php ENDPATH**/ ?>