<?php $__env->startSection('content'); ?>
	<a class="float-right mx-5 my-2" href="<?php echo e(route('login')); ?>">Přihlásit se</a>

	<div id="admin-content">
			<div class="container">
					<div class="row">
							<div class="col-md-3">
									<h2 class="admin-heading">Seznam knih</h2>
							</div>
					</div>
					<div class="row">
							<div class="col-md-12">
									<div class="message"></div>
									<table class="content-table">
											<thead>
													<th>ISBN</th>
													<th>Název</th>
													<th>Kategorie</th>
													<th>Autor</th>
													<th>Vydavatel</th>
													<th>Stav</th>
													<th>Náhled</th>
											</thead>
											<tbody>
													<?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
															<tr>
																	<td class="id"><?php echo e($book->isbn ?? "---"); ?></td>
																	<td><?php echo e($book->name ?? "---"); ?></td>
																	<td><?php echo e($book->category->name ?? "---"); ?></td>
																	<td><?php echo e($book->auther->name ?? "---"); ?></td>
																	<td><?php echo e($book->publisher->name ?? "---"); ?></td>
																	<td>
																			<?php if($book->status == 'Y'): ?>
																					<span class='badge badge-success'>Dostupné</span>
																			<?php else: ?>
																					<span class='badge badge-danger'>Vypůjčeno</span>
																			<?php endif; ?>
																	</td>
																	<td class="view">
																		<a href="<?php echo e(route('view', $book->id)); ?>" class="btn btn-success">Náhled</a>
																	</td>
															</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
															<tr>
																	<td colspan="8">Žádné knihy v databázi.</td>
															</tr>
													<?php endif; ?>
											</tbody>
									</table>
									<?php echo e($books->links('vendor/pagination/bootstrap-4')); ?>

							</div>
					</div>
			</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patryk/eclipse-workspace/Laravel-library-management-system/resources/views/guests/book_list.blade.php ENDPATH**/ ?>