<?php $__env->startSection('content'); ?>
<div id="admin-content">
	<div class="container">
		<p>Vyberte .csv soubor se záznamy knih, které si přejete importovat. <b>Podporovány jsou csv soubory z aplikace HandyLibrary.</b></p>
		<form class="" action="/upload/store" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<input type="file" name="uploaded_file" accept=".csv">
			<input type="submit" name="odeslat" value="Odeslat" class="btn btn-success">
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patryk/eclipse-workspace/Laravel-library-management-system/resources/views/upload/upload.blade.php ENDPATH**/ ?>